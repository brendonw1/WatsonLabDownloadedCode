%ENCRYPT   Encrypt text in Post Script
%   ENCRYPT(TEXT,KEY) takes uint8 TEXT array and uint16 KEY and returns the
%   encrypted data

% Copyright 2012 Takeshi Ikuma
% History:
% rev. - : (03-15-2012) original release

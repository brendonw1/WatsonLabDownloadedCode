%% Upslope Area Toolbox System Requirements
% Upslope Area Toolbox requires MATLAB(R) and Image Processing Toolbox(TM).
%
% Copyright 2009 The MathWorks, Inc.
